<?php $__env->startSection('title', 'Administración de pedidos'); ?>

<?php $__env->startSection('header', 'Administración de pedidos'); ?>

<?php $__env->startSection('main_title', 'Insertar/modificar pedido'); ?>

<?php $__env->startSection('content'); ?>
    <?php if(isset($order)): ?>
        <br><br>
        <form action="<?php echo e(route('order.update', ['order' => $order->id])); ?>" method="GET">
            <?php echo method_field('PATCH'); ?>
    <?php else: ?>
        <form action="<?php echo e(route('order.create')); ?>" method="GET">
    <?php endif; ?>
            <?php echo csrf_field(); ?>
            <br>
            <table class='sinbordes'>
                <tr>
                    <td class='sinbordes'>Producto:</td>
                    <td class='sinbordes'>
                        <select>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($product->id); ?>"><?php echo e($product->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td class='sinbordes'>Proveedor:</td>
                    <td class='sinbordes'>
                        <select>
                            <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($supplier->id); ?>"><?php echo e($supplier->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td class='sinbordes'>Empleado de compras:</td>
                    <td class='sinbordes'>
                        <select>
                            <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($employee->id); ?>"><?php echo e($employee->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td class='sinbordes'>Cantidad:</td>
                    <td class='sinbordes'><input type="text" name="amount" value="<?php echo e($order->amount ?? ''); ?>" required></td>
                </tr>
                <tr>
                    <td class='sinbordes'>Precio:</td>
                    <td class='sinbordes'><input type="text" name="price" value="<?php echo e($order->price ?? ''); ?>" required></td>
                </tr>
                <tr>
                    <td class='sinbordes'>Comentarios:</td>
                    <td class='sinbordes'><input type="text" name="comments" value="<?php echo e($order->comments ?? ''); ?>" required></td>
                </tr>
                <tr>
                    <td class='sinbordes'><a href="<?php echo e(route('order.status')); ?>">Volver al listado</a></td>
                    <td class='sinbordes'><input type="submit"></td>
                </tr>
            </table>
        </form>

        <br><br>
        <form action = "<?php echo e(route('menu')); ?>" method="GET" class="centrado">
            <?php echo csrf_field(); ?>
            <input type="submit" value="MENÚ PRINCIPAL">
        </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programas\XAMPP\htdocs\laravel\examen_eva2\resources\views/order/update.blade.php ENDPATH**/ ?>