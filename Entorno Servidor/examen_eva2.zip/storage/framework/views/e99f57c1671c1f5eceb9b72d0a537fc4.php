<?php $__env->startSection('title', 'Pedidos por empleado'); ?>

<?php $__env->startSection('header', 'Pedidos por empleado'); ?>

<?php $__env->startSection('main_title', 'Solicitar productos'); ?>

<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('order.resume')); ?>" method="GET">
    <?php echo csrf_field(); ?>
    <br>
    <table class='sinbordes'>
        <tr>
            <td class='sinbordes'>Empleado solicitante:</td>
            <td class='sinbordes'>
                <select name="employee_id">
                    <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($employee->id); ?>"><?php echo e($employee->name); ?> <?php echo e($employee->surname); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </td>
        </tr>
        <tr>
            <td class='sinbordes superior'>Producto solicitado:</td>
            <td class='sinbordes'>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <input type="radio" name="product" value="<?php echo e($product->id); ?>"
                    <?php if($product->id == 1): ?>
                        checked
                    <?php endif; ?>
                    ><?php echo e($product->name); ?></radio><br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </td>
        </tr>
        <tr>
            <td class='sinbordes'>Cantidad a comprar:</td>
            <td class='sinbordes'>
                <input type="number" name="cantidad" min="0" required>
                <input type="submit" value="Realizar pedido">
            </td>
        </tr>
    </table>
    </form>

    <br><br>
    <form action = "<?php echo e(route('menu')); ?>" method="GET" class="centrado">
        <?php echo csrf_field(); ?>
        <input type="submit" value="MENÚ PRINCIPAL">
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programas\XAMPP\htdocs\laravel\examen_eva2\resources\views/order/form.blade.php ENDPATH**/ ?>